package net.dingdingduang.somebasicskills.networking;

public interface Function0<R> {
    R apply();
}
