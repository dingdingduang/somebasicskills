package net.dingdingduang.somebasicskills.resourcelocation.icon;

import net.minecraft.resources.ResourceLocation;
import net.dingdingduang.somebasicskills.Constants;

import static net.dingdingduang.somebasicskills.globalmethods.GeneralMethods.getMCResourceLocation;

public class IconBasicResourceLocation {
    public static final ResourceLocation SKILL_BACKGROUND = getMCResourceLocation(Constants.MOD_ID, "textures/gui/background.png");

    public static final ResourceLocation ICON_OVERLAY = getMCResourceLocation(Constants.MOD_ID, "textures/gui/icon_overlay.png");
    public static final ResourceLocation ICON_BG_EXPAND = getMCResourceLocation(Constants.MOD_ID, "textures/gui/iconbg_expand.png");

    public static final ResourceLocation ICON_ADD = getMCResourceLocation(Constants.MOD_ID, "textures/gui/btn_add.png");
    public static final ResourceLocation ICON_ADD_HOVERGLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/btn_add_hoverglow.png");
    public static final ResourceLocation ICON_ADD_PRESSED = getMCResourceLocation(Constants.MOD_ID, "textures/gui/btn_add_pressed.png");
    public static final ResourceLocation DISICON_ADD = getMCResourceLocation(Constants.MOD_ID, "textures/gui/disbtn_add.png");
    public static final ResourceLocation ICON_SUB = getMCResourceLocation(Constants.MOD_ID, "textures/gui/btn_sub.png");
    public static final ResourceLocation ICON_SUB_HOVERGLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/btn_sub_hoverglow.png");
    public static final ResourceLocation ICON_SUB_PRESSED = getMCResourceLocation(Constants.MOD_ID, "textures/gui/btn_sub_pressed.png");
    public static final ResourceLocation DISICON_SUB = getMCResourceLocation(Constants.MOD_ID, "textures/gui/disbtn_sub.png");
    public static final ResourceLocation ICON_MAX = getMCResourceLocation(Constants.MOD_ID, "textures/gui/btn_max.png");
    public static final ResourceLocation ICON_MAX_HOVERGLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/btn_max_hoverglow.png");
    public static final ResourceLocation ICON_MAX_PRESSED = getMCResourceLocation(Constants.MOD_ID, "textures/gui/btn_max_pressed.png");
    public static final ResourceLocation DISICON_MAX = getMCResourceLocation(Constants.MOD_ID, "textures/gui/disbtn_max.png");

    public static final ResourceLocation KEYBOARD_QUCIKSLOT_ASSIGN = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_keyboardicon.png");
    public static final ResourceLocation KEYBOARD_QUCIKSLOT_ASSIGN_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_keyboardicon_glow.png");
    public static final ResourceLocation KEYBOARD_RESET_QUCIKSLOT_ASSIGN = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/reset_gui_keyboardicon.png");
    public static final ResourceLocation KEYBOARD_RESET_QUCIKSLOT_ASSIGN_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/reset_gui_keyboardicon_glow.png");
    public static final ResourceLocation KEY_COMBO_SETTING = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/keycombosetting.png");
    public static final ResourceLocation KEY_COMBO_SETTING_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/keycombosetting_glow.png");
    public static final ResourceLocation KEY_COMBO_RESET_SETTING = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/resetkeycombosetting.png");
    public static final ResourceLocation KEY_COMBO_RESET_SETTING_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/resetkeycombosetting_glow.png");

    public static final ResourceLocation ICON_FRAME_BACKGROUND = getMCResourceLocation(Constants.MOD_ID, "textures/gui/36x36/skill_icon_36x36.png");
    public static final ResourceLocation PROGRESSBAR = getMCResourceLocation(Constants.MOD_ID, "textures/gui/progressbar/progressbar.png");
    public static final ResourceLocation PROGRESSBAR_FORWARD = getMCResourceLocation(Constants.MOD_ID, "textures/gui/progressbar/progressbar_forward.png");
    public static final ResourceLocation PROGRESSBAR_BACKGROUND = getMCResourceLocation(Constants.MOD_ID, "textures/gui/progressbar/progressbar_background.png");

    public static final ResourceLocation GUI_SB_GENERAL_SETTING_ICON = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_general_setting.png");
    public static final ResourceLocation GUI_SB_GENERAL_SETTING_ICON_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_general_setting_glow.png");

    public static final ResourceLocation GUI_SB_RESET_STATE_ICON = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/gui_state_reset.png");
    public static final ResourceLocation GUI_SB_RESET_STATE_ICON_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/gui_state_reset_glow.png");

    public static final ResourceLocation GUI_PRIORITY_SETTING_ICON = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_priority.png");
    public static final ResourceLocation GUI_PRIORITY_SETTING_ICON_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_priority_glow.png");
    public static final ResourceLocation GUI_PRIORITY_RESET_SETTING_ICON = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/reset_gui_priority.png");
    public static final ResourceLocation GUI_PRIORITY_RESET_SETTING_ICON_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/reset_gui_priority_glow.png");

    public static final ResourceLocation GUI_SKILL_COOLDOWN_DELAY_ICON = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/gui_cooldown_delay.png");
    public static final ResourceLocation GUI_SKILL_COOLDOWN_DELAY_ICON_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/gui_cooldown_delay_glow.png");
    public static final ResourceLocation GUI_SKILL_RESET_COOLDOWN_DELAY_ICON = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/gui_cooldown_delay_reset.png");
    public static final ResourceLocation GUI_SKILL_RESET_COOLDOWN_DELAY_ICON_GLOW = getMCResourceLocation(Constants.MOD_ID, "textures/gui/32x32/gui_cooldown_delay_reset_glow.png");

    //condition option
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_0 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_0.png");
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_1 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_1.png");
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_2 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_2.png");
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_3 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_3.png");
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_4 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_4.png");
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_5 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_5.png");
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_6 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_6.png");
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_7 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_7.png");
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_8 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_8.png");
//    public static final ResourceLocation GUI_CONDITION_OPTION_NUM_9 = getMCResourceLocation(Constants.MOD_ID, "textures/gui/16x16/gui_condition_num_9.png");
//
//    public static final ResourceLocation[] GUI_CONDITION_OPTIONS = {GUI_CONDITION_OPTION_NUM_0,
//            GUI_CONDITION_OPTION_NUM_1, GUI_CONDITION_OPTION_NUM_2, GUI_CONDITION_OPTION_NUM_3,
//            GUI_CONDITION_OPTION_NUM_4, GUI_CONDITION_OPTION_NUM_5, GUI_CONDITION_OPTION_NUM_6,
//            GUI_CONDITION_OPTION_NUM_7, GUI_CONDITION_OPTION_NUM_8, GUI_CONDITION_OPTION_NUM_9};
}
