package net.dingdingduang.somebasicskills.sbsattributes;

import net.minecraft.world.entity.ai.attributes.Attribute;

public class SBSAttribute extends Attribute {
    public SBSAttribute(String pDescriptionId, double pDefaultValue) {
        super(pDescriptionId, pDefaultValue);
    }
}
