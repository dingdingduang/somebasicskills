package net.dingdingduang.somebasicskills.util;

public interface SkillClientConditionRequirement {
    boolean executeAction(String SkillID);
}
