package net.dingdingduang.somebasicskills.util;

import net.minecraft.world.entity.Entity;

public interface MethodEntityAction {
    void executeAction(Entity entity);
}
