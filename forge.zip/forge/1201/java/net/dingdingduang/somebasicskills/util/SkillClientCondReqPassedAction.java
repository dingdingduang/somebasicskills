package net.dingdingduang.somebasicskills.util;

public interface SkillClientCondReqPassedAction {
    void executeAction(String SkillID);
}
