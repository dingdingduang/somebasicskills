package net.dingdingduang.somebasicskills.util;

import net.minecraft.world.entity.LivingEntity;

public interface MethodAction {
    void executeAction(LivingEntity entity1);
}
