package net.dingdingduang.somebasicskills.sbsattributes;

import net.minecraft.entity.attribute.EntityAttribute;

public class SBSAttribute extends EntityAttribute {
    public SBSAttribute(String pDescriptionId, double pDefaultValue) {
        super(pDescriptionId, pDefaultValue);
    }
}
