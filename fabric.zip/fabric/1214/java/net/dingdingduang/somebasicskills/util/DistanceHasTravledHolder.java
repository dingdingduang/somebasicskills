package net.dingdingduang.somebasicskills.util;

public class DistanceHasTravledHolder {
    private float distHasTraveled;

    public DistanceHasTravledHolder(float tempDistHasTraveled) {
        this.distHasTraveled = tempDistHasTraveled;
    }

    public float getDistHasTraveled() {
        return distHasTraveled;
    }

    public void setDistHasTraveled(float distHasTraveled) {
        this.distHasTraveled = distHasTraveled;
    }
}
