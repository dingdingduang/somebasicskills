package net.dingdingduang.somebasicskills.util;

public interface MethodConfigAction {
    void ConfigSetting(String configName, String configDetailName, MethodConfigHelper configHelper);
}
