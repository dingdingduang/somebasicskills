package net.dingdingduang.somebasicskills.util;

import net.minecraft.entity.Entity;

public interface MethodEntityAction {
    void executeAction(Entity entity);
}
