package net.dingdingduang.somebasicskills.mixin;

import net.dingdingduang.somebasicskills.globalmethods.MixinMethodCallHelper;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

import static net.dingdingduang.somebasicskills.globalmethods.GeneralMethods.printInGameMsg;

@Mixin(PlayerEntity.class)
public abstract class SBSPlayerEntityOnHurtEventMixin extends LivingEntity {
    protected SBSPlayerEntityOnHurtEventMixin(EntityType<? extends LivingEntity> entityType, World world) {
        super(entityType, world);
    }

    //    @ModifyVariable(method = "applyDamage", at = @At(value = "STORE", ordinal = 1), ordinal = 0, argsOnly = true)
//    @Inject(method = "applyDamage", at = @At("HEAD"))
//    private void SBSonArmorToDamage(DamageSource source, float amount, CallbackInfo ci) {
//        LivingEntity target = (LivingEntity) this.world.getEntityById(this.hashCode());
//
//        amount = 0;
//
//
//        MixinMethodCallHelper.helper.LivingEntityOnHurtExtraAction(target, source, amount);
//    }

    //    @ModifyVariable(method = "applyDamage", at = @At(value = "STORE", ordinal = 1), ordinal = 0, argsOnly = true)
//    @Inject(method = "applyDamage", at = @At("HEAD"))
//    private void SBSonArmorToDamage(DamageSource source, float amount, CallbackInfo ci) {
//        LivingEntity target = (LivingEntity) this.world.getEntityById(this.hashCode());
//
//        amount = 0;
//
//
//        MixinMethodCallHelper.helper.LivingEntityOnHurtExtraAction(target, source, amount);
//    }

//    @ModifyArg(method = "applyDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;applyArmorToDamage(Lnet/minecraft/entity/damage/DamageSource;F)F"), index = 1, allow = 1)
//    @ModifyVariable(method = "applyDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;applyArmorToDamage(Lnet/minecraft/entity/damage/DamageSource;F)F"), ordinal = 0, argsOnly = true)
    @ModifyArgs(method = "applyDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;applyArmorToDamage(Lnet/minecraft/entity/damage/DamageSource;F)F"))
    private void SBSonArmorToDamage(Args args) {
        DamageSource damageSource = args.get(0);
        float incomingDMG = args.get(1);
        LivingEntity target = (LivingEntity) this.getWorld().getEntityById(this.hashCode());

//        if (target == null) { return; }
//        else { printInGameMsg("n: "+target.getName().getString()); }
        incomingDMG = MixinMethodCallHelper.helper.LivingEntityOnHurtAction(target, damageSource, incomingDMG);

        args.set(1, incomingDMG);
    }

//    @ModifyArg(method = "applyDamage", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;applyArmorToDamage(Lnet/minecraft/entity/damage/DamageSource;F)F"), index = 1, allow = 1)
//    private float SBSonArmorToDamage(float amount) {
//        return 0;
//    }
}
