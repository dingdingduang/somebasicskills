package net.dingdingduang.dfoswordmanskilltree.entity;

public final class DfoMinecraftDefaultEntitiesRegistryConstants {
    public static final String CLIENT_MOVEMENT_HELPER_STR_ID = "clientmovementhelper";
}
