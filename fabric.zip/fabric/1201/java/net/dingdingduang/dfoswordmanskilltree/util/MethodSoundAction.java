package net.dingdingduang.dfoswordmanskilltree.util;

import net.minecraft.world.World;

public interface MethodSoundAction {
    void executeSoundAction(World worldLevel, double x1, double y1, double z1, float volume, float pitch);
}
