package net.dingdingduang.dfoswordmanskilltree.globalvalues;

public class DfoSwdGlobalServerValue {
    private static boolean isDfoSwdGlobalValInit = false;

    public static boolean isDfoSwdGlobalValInit() { return isDfoSwdGlobalValInit; }
    public static void setDfoSwdGlobalValInit(boolean dfoSwdGlobalValInit) { isDfoSwdGlobalValInit = dfoSwdGlobalValInit; }
}
