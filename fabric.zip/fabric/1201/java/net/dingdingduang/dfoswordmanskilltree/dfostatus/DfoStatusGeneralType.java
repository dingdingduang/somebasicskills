package net.dingdingduang.dfoswordmanskilltree.dfostatus;

public class DfoStatusGeneralType {
    private int ElementDamageType;

    public DfoStatusGeneralType(int type) {
        this.ElementDamageType = type;
    }

    public int getElementDamageType() { return this.ElementDamageType; }
    public void setElementDamageType(int elementDamageType) { this.ElementDamageType = elementDamageType; }
}
